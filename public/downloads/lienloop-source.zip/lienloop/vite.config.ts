import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import {localAgentPlugin} from './scripts/local-agent-plugin';
export default defineConfig({define:{'import.meta.env.VITE_LIENLOOP_AGENT_UI':JSON.stringify(process.env.LIENLOOP_ENABLE_AGENT_UI==='1')},plugins:[react(),...(process.env.LIENLOOP_ENABLE_AGENT_UI==='1'?[localAgentPlugin()]:[])],server:{allowedHosts:process.env.LIENLOOP_ENABLE_AGENT_UI==='1'?['localhost','127.0.0.1']:true}});
